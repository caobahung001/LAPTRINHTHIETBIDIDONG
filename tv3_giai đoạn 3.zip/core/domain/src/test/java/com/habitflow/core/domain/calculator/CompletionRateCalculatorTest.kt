package com.habitflow.core.domain.calculator

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class CompletionRateCalculatorTest {

    @Test
    fun `calculateDailyCompletionRate returns correct percentage ignoring skipped`() {
        val today = LocalDate.now()
        val occurrences = listOf(
            HabitOccurrence(habitId = 1, date = today, status = OccurrenceStatus.COMPLETED),
            HabitOccurrence(habitId = 2, date = today, status = OccurrenceStatus.SKIPPED),
            HabitOccurrence(habitId = 3, date = today, status = OccurrenceStatus.PENDING)
        )

        val rate = CompletionRateCalculator.calculateDailyCompletionRate(occurrences)

        // 1 completed out of 2 non-skipped = 50.0%
        assertEquals(50.0, rate, 0.01)
    }
}