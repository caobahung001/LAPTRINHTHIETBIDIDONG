package com.habitflow.core.domain.calculator

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class StreakCalculatorTest {

    @Test
    fun `calculateStreak handles consecutive completed days correctly`() {
        val today = LocalDate.of(2026, 8, 23)
        val occurrences = listOf(
            HabitOccurrence(habitId = 1, date = today, status = OccurrenceStatus.COMPLETED),
            HabitOccurrence(habitId = 1, date = today.minusDays(1), status = OccurrenceStatus.COMPLETED),
            HabitOccurrence(habitId = 1, date = today.minusDays(2), status = OccurrenceStatus.COMPLETED)
        )

        val streakInfo = StreakCalculator.calculateStreak(occurrences, today)

        assertEquals(3, streakInfo.currentStreak)
        assertEquals(3, streakInfo.bestStreak)
        assertEquals(true, streakInfo.isMilestoneReached)
    }

    @Test
    fun `calculateStreak skipped status does not break streak`() {
        val today = LocalDate.of(2026, 8, 23)
        val occurrences = listOf(
            HabitOccurrence(habitId = 1, date = today, status = OccurrenceStatus.COMPLETED),
            HabitOccurrence(habitId = 1, date = today.minusDays(1), status = OccurrenceStatus.SKIPPED),
            HabitOccurrence(habitId = 1, date = today.minusDays(2), status = OccurrenceStatus.COMPLETED)
        )

        val streakInfo = StreakCalculator.calculateStreak(occurrences, today)

        assertEquals(2, streakInfo.currentStreak)
    }
}