package com.habitflow.core.domain.calculator

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.model.StreakMilestoneInfo
import java.time.LocalDate

object StreakCalculator {

    private val MILESTONES = listOf(3, 7, 14, 21, 30, 50, 100, 365)

    /**
     * Calculates current streak, longest streak, and milestone detection from historical occurrences.
     * Skipped occurrences do not break streaks.
     */
    fun calculateStreak(
        occurrences: List<HabitOccurrence>,
        today: LocalDate = LocalDate.now()
    ): StreakMilestoneInfo {
        if (occurrences.isEmpty()) {
            return StreakMilestoneInfo(currentStreak = 0, bestStreak = 0)
        }

        val occurrencesByDate = occurrences.associateBy { it.date }
        
        var currentStreak = 0
        var bestStreak = 0
        var tempStreak = 0

        // Calculate current active streak backwards from today or yesterday
        var checkDate = today
        // If today is pending, check if yesterday was active to keep streak alive
        val todayOccurrence = occurrencesByDate[today]
        if (todayOccurrence == null || todayOccurrence.status == OccurrenceStatus.PENDING) {
            checkDate = today.minusDays(1)
        }

        while (true) {
            val occ = occurrencesByDate[checkDate] ?: break
            when (occ.status) {
                OccurrenceStatus.COMPLETED -> {
                    currentStreak++
                    checkDate = checkDate.minusDays(1)
                }
                OccurrenceStatus.SKIPPED -> {
                    // Skipped maintains streak without incrementing count
                    checkDate = checkDate.minusDays(1)
                }
                OccurrenceStatus.MISSED, OccurrenceStatus.PENDING -> {
                    break
                }
            }
        }

        // Calculate historical best streak
        val sortedDates = occurrencesByDate.keys.sorted()
        for (date in sortedDates) {
            val occ = occurrencesByDate[date] ?: continue
            when (occ.status) {
                OccurrenceStatus.COMPLETED -> {
                    tempStreak++
                    if (tempStreak > bestStreak) {
                        bestStreak = tempStreak
                    }
                }
                OccurrenceStatus.SKIPPED -> {
                    // Streak stays preserved
                }
                OccurrenceStatus.MISSED -> {
                    tempStreak = 0
                }
                OccurrenceStatus.PENDING -> {
                    if (date.isBefore(today)) {
                        tempStreak = 0
                    }
                }
            }
        }

        bestStreak = maxOf(bestStreak, currentStreak)
        val isMilestone = currentStreak in MILESTONES
        val milestoneMsg = if (isMilestone) "Chúc mừng! Bạn đã đạt cột mốc $currentStreak ngày liên tiếp! 🔥" else null

        return StreakMilestoneInfo(
            currentStreak = currentStreak,
            bestStreak = bestStreak,
            isMilestoneReached = isMilestone,
            milestoneMessage = milestoneMsg
        )
    }
}