package com.habitflow.core.domain.usecase.occurrence

import com.habitflow.core.domain.repository.OccurrenceRepository
import java.time.LocalDate
import javax.inject.Inject

class AddValueHabitUseCase @Inject constructor(
    private val repository: OccurrenceRepository
) {
    suspend operator fun invoke(
        habitId: Long,
        value: Double,
        date: LocalDate = LocalDate.now(),
        note: String? = null
    ) {
        repository.addValueOccurrence(habitId, date, value, note)
    }
}