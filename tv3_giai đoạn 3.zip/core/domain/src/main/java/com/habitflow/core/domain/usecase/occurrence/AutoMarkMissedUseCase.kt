package com.habitflow.core.domain.usecase.occurrence

import com.habitflow.core.domain.repository.OccurrenceRepository
import java.time.LocalDate
import javax.inject.Inject

class AutoMarkMissedUseCase @Inject constructor(
    private val repository: OccurrenceRepository
) {
    suspend operator fun invoke(today: LocalDate = LocalDate.now()): Int {
        return repository.autoMarkMissed(today)
    }
}