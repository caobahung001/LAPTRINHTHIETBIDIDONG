package com.habitflow.core.domain.model

import java.time.LocalDate
import java.time.LocalDateTime

enum class OccurrenceStatus {
    PENDING,
    COMPLETED,
    SKIPPED,
    MISSED
}

data class HabitOccurrence(
    val id: Long = 0,
    val habitId: Long,
    val habitName: String = "",
    val habitIcon: String = "check_circle",
    val habitColorHex: String = "#4CAF50",
    val isNumeric: Boolean = false,
    val targetValue: Double = 1.0,
    val currentValue: Double = 0.0,
    val unit: String = "",
    val date: LocalDate,
    val status: OccurrenceStatus = OccurrenceStatus.PENDING,
    val note: String? = null,
    val updatedAt: LocalDateTime = LocalDateTime.now()
) {
    val isCompleted: Boolean get() = status == OccurrenceStatus.COMPLETED
    val isSkipped: Boolean get() = status == OccurrenceStatus.SKIPPED
    val isMissed: Boolean get() = status == OccurrenceStatus.MISSED
    val isPending: Boolean get() = status == OccurrenceStatus.PENDING

    val progressFraction: Float
        get() = if (targetValue > 0) (currentValue / targetValue).coerceIn(0.0, 1.0).toFloat() else 0f
}