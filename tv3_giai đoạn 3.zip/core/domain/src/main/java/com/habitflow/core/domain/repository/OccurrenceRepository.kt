package com.habitflow.core.domain.repository

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

interface OccurrenceRepository {
    fun getTodayOccurrences(date: LocalDate): Flow<List<HabitOccurrence>>
    fun getOccurrencesForHabit(habitId: Long): Flow<List<HabitOccurrence>>
    suspend fun completeOccurrence(habitId: Long, date: LocalDate, note: String? = null)
    suspend fun skipOccurrence(habitId: Long, date: LocalDate, note: String? = null)
    suspend fun addValueOccurrence(habitId: Long, date: LocalDate, addedValue: Double, note: String? = null)
    suspend fun undoOccurrence(habitId: Long, date: LocalDate)
    suspend fun autoMarkMissed(today: LocalDate): Int
}