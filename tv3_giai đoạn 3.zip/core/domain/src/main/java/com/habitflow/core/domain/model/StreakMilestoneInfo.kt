package com.habitflow.core.domain.model

data class StreakMilestoneInfo(
    val currentStreak: Int,
    val bestStreak: Int,
    val isMilestoneReached: Boolean = false,
    val milestoneMessage: String? = null
)