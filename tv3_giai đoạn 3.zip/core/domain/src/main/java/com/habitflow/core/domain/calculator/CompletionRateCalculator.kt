package com.habitflow.core.domain.calculator

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus

object CompletionRateCalculator {

    /**
     * Calculates the completion rate percentage (0.0 to 100.0) for today's habits.
     */
    fun calculateDailyCompletionRate(occurrences: List<HabitOccurrence>): Double {
        if (occurrences.isEmpty()) return 0.0
        val evaluableList = occurrences.filter { it.status != OccurrenceStatus.SKIPPED }
        if (evaluableList.isEmpty()) return 100.0

        val completedCount = evaluableList.count { it.status == OccurrenceStatus.COMPLETED }
        return (completedCount.toDouble() / evaluableList.size) * 100.0
    }

    /**
     * Calculates progress summary string (e.g. "3/5 hoàn thành").
     */
    fun getCompletionSummaryText(occurrences: List<HabitOccurrence>): String {
        val total = occurrences.size
        val completed = occurrences.count { it.status == OccurrenceStatus.COMPLETED }
        val skipped = occurrences.count { it.status == OccurrenceStatus.SKIPPED }
        return if (skipped > 0) {
            "$completed/$total hoàn thành ($skipped đã bỏ qua)"
        } else {
            "$completed/$total hoàn thành"
        }
    }
}