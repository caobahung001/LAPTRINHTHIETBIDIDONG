package com.habitflow.core.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.habitflow.core.database.entity.HabitOccurrenceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OccurrenceDao {

    @Query("SELECT * FROM habit_occurrences WHERE date = :date")
    fun getOccurrencesForDate(date: String): Flow<List<HabitOccurrenceEntity>>

    @Query("SELECT * FROM habit_occurrences WHERE habit_id = :habitId AND date = :date LIMIT 1")
    suspend fun getOccurrence(habitId: Long, date: String): HabitOccurrenceEntity?

    @Query("SELECT * FROM habit_occurrences WHERE habit_id = :habitId ORDER BY date DESC")
    fun getOccurrencesForHabit(habitId: Long): Flow<List<HabitOccurrenceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOccurrence(occurrence: HabitOccurrenceEntity): Long

    @Update
    suspend fun updateOccurrence(occurrence: HabitOccurrenceEntity)

    @Query("UPDATE habit_occurrences SET status = 'MISSED' WHERE date < :today AND status = 'PENDING'")
    suspend fun markMissedForPastDates(today: String): Int

    @Query("DELETE FROM habit_occurrences WHERE habit_id = :habitId AND date = :date")
    suspend fun deleteOccurrence(habitId: Long, date: String)
}