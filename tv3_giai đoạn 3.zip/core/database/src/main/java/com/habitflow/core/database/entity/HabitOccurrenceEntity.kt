package com.habitflow.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "habit_occurrences",
    indices = [
        Index(value = ["habit_id", "date"], unique = true) // Prevents duplicate occurrences per habit/date
    ]
)
data class HabitOccurrenceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "habit_id")
    val habitId: Long,
    @ColumnInfo(name = "date")
    val date: String, // YYYY-MM-DD
    @ColumnInfo(name = "status")
    val status: String, // PENDING, COMPLETED, SKIPPED, MISSED
    @ColumnInfo(name = "current_value")
    val currentValue: Double = 0.0,
    @ColumnInfo(name = "note")
    val note: String? = null,
    @ColumnInfo(name = "updated_at")
    val updatedAt: String // ISO-8601 Timestamp
)