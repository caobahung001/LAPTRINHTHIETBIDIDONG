package com.habitflow.core.data.mapper

import com.habitflow.core.database.entity.HabitOccurrenceEntity
import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import java.time.LocalDate
import java.time.LocalDateTime

fun HabitOccurrenceEntity.toDomainModel(
    habitName: String = "",
    habitIcon: String = "check_circle",
    habitColorHex: String = "#4CAF50",
    isNumeric: Boolean = false,
    targetValue: Double = 1.0,
    unit: String = ""
): HabitOccurrence {
    return HabitOccurrence(
        id = id,
        habitId = habitId,
        habitName = habitName,
        habitIcon = habitIcon,
        habitColorHex = habitColorHex,
        isNumeric = isNumeric,
        targetValue = targetValue,
        currentValue = currentValue,
        unit = unit,
        date = LocalDate.parse(date),
        status = OccurrenceStatus.valueOf(status),
        note = note,
        updatedAt = try { LocalDateTime.parse(updatedAt) } catch (e: Exception) { LocalDateTime.now() }
    )
}

fun HabitOccurrence.toEntity(): HabitOccurrenceEntity {
    return HabitOccurrenceEntity(
        id = id,
        habitId = habitId,
        date = date.toString(),
        status = status.name,
        currentValue = currentValue,
        note = note,
        updatedAt = LocalDateTime.now().toString()
    )
}