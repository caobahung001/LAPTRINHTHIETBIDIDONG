package com.habitflow.core.data.repository

import com.habitflow.core.data.mapper.toDomainModel
import com.habitflow.core.data.mapper.toEntity
import com.habitflow.core.database.dao.OccurrenceDao
import com.habitflow.core.database.entity.HabitOccurrenceEntity
import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.repository.OccurrenceRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.LocalDateTime
import javax.inject.Inject

class OfflineOccurrenceRepository @Inject constructor(
    private val occurrenceDao: OccurrenceDao
) : OccurrenceRepository {

    override fun getTodayOccurrences(date: LocalDate): Flow<List<HabitOccurrence>> {
        return occurrenceDao.getOccurrencesForDate(date.toString()).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override fun getOccurrencesForHabit(habitId: Long): Flow<List<HabitOccurrence>> {
        return occurrenceDao.getOccurrencesForHabit(habitId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override suspend fun completeOccurrence(habitId: Long, date: LocalDate, note: String?) {
        val existing = occurrenceDao.getOccurrence(habitId, date.toString())
        val updatedEntity = HabitOccurrenceEntity(
            id = existing?.id ?: 0,
            habitId = habitId,
            date = date.toString(),
            status = OccurrenceStatus.COMPLETED.name,
            currentValue = existing?.currentValue ?: 1.0,
            note = note ?: existing?.note,
            updatedAt = LocalDateTime.now().toString()
        )
        occurrenceDao.upsertOccurrence(updatedEntity)
    }

    override suspend fun skipOccurrence(habitId: Long, date: LocalDate, note: String?) {
        val existing = occurrenceDao.getOccurrence(habitId, date.toString())
        val updatedEntity = HabitOccurrenceEntity(
            id = existing?.id ?: 0,
            habitId = habitId,
            date = date.toString(),
            status = OccurrenceStatus.SKIPPED.name,
            currentValue = existing?.currentValue ?: 0.0,
            note = note ?: existing?.note,
            updatedAt = LocalDateTime.now().toString()
        )
        occurrenceDao.upsertOccurrence(updatedEntity)
    }

    override suspend fun addValueOccurrence(
        habitId: Long,
        date: LocalDate,
        addedValue: Double,
        note: String?
    ) {
        val existing = occurrenceDao.getOccurrence(habitId, date.toString())
        val newCount = (existing?.currentValue ?: 0.0) + addedValue
        val updatedEntity = HabitOccurrenceEntity(
            id = existing?.id ?: 0,
            habitId = habitId,
            date = date.toString(),
            status = OccurrenceStatus.COMPLETED.name, // Marked complete when adding value
            currentValue = newCount,
            note = note ?: existing?.note,
            updatedAt = LocalDateTime.now().toString()
        )
        occurrenceDao.upsertOccurrence(updatedEntity)
    }

    override suspend fun undoOccurrence(habitId: Long, date: LocalDate) {
        val existing = occurrenceDao.getOccurrence(habitId, date.toString())
        if (existing != null) {
            val updatedEntity = existing.copy(
                status = OccurrenceStatus.PENDING.name,
                currentValue = 0.0,
                updatedAt = LocalDateTime.now().toString()
            )
            occurrenceDao.upsertOccurrence(updatedEntity)
        }
    }

    override suspend fun autoMarkMissed(today: LocalDate): Int {
        return occurrenceDao.markMissedForPastDates(today.toString())
    }
}