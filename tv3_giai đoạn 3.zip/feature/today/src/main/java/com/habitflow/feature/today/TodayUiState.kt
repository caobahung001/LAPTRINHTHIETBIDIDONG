package com.habitflow.feature/today

import com.habitflow.core.domain.model.HabitOccurrence
import java.time.LocalDate

data class TodayUiState(
    val isLoading: Boolean = true,
    val selectedDate: LocalDate = LocalDate.now(),
    val occurrences: List<HabitOccurrence> = emptyList(),
    val completionPercentage: Float = 0f,
    val completionSummaryText: String = "0/0 hoàn thành",
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val milestoneMessage: String? = null,
    val isValueInputDialogVisible: Boolean = false,
    val targetHabitForValue: HabitOccurrence? = null,
    val errorMessage: String? = null
)