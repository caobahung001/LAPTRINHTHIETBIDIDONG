package com.habitflow.feature.today

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus

@Composable
fun TodayHeaderProgressCard(
    completionPercentage: Float,
    summaryText: String,
    currentStreak: Int,
    bestStreak: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Tiến độ hôm nay",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = summaryText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
                
                // Streak Badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    modifier = Modifier.padding(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🔥 ", fontSize = 14.sp)
                        Text(
                            text = "$currentStreak ngày",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val animatedProgress by animateFloatAsState(
                targetValue = (completionPercentage / 100f).coerceIn(0f, 1f),
                label = "ProgressAnimation"
            )

            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
fun HabitOccurrenceItem(
    occurrence: HabitOccurrence,
    onAction: (TodayAction) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = occurrence.habitName.ifEmpty { "Thói quen #" + occurrence.habitId },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                if (occurrence.isNumeric) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tiến độ: ${occurrence.currentValue}/${occurrence.targetValue} ${occurrence.unit}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                StatusChip(status = occurrence.status)
            }

            // Quick Action Buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
                when (occurrence.status) {
                    OccurrenceStatus.PENDING -> {
                        if (occurrence.isNumeric) {
                            Button(
                                onClick = { onAction(TodayAction.OpenValueInputDialog(occurrence)) },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("+ Nhập")
                            }
                        } else {
                            IconButton(
                                onClick = { onAction(TodayAction.CompleteHabit(occurrence.habitId)) },
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Hoàn thành")
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = { onAction(TodayAction.SkipHabit(occurrence.habitId)) },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Bỏ qua")
                        }
                    }
                    OccurrenceStatus.COMPLETED, OccurrenceStatus.SKIPPED, OccurrenceStatus.MISSED -> {
                        IconButton(
                            onClick = { onAction(TodayAction.UndoHabit(occurrence.habitId)) }
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Hoàn tác")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusChip(status: OccurrenceStatus) {
    val (bgColor, textColor, label) = when (status) {
        OccurrenceStatus.PENDING -> Triple(Color(0xFFFFF3E0), Color(0xFFE65100), "Chưa xong")
        OccurrenceStatus.COMPLETED -> Triple(Color(0xFFE8F5E9), Color(0xFF2E7D32), "Đã hoàn thành")
        OccurrenceStatus.SKIPPED -> Triple(Color(0xFFECEFF1), Color(0xFF455A64), "Đã bỏ qua")
        OccurrenceStatus.MISSED -> Triple(Color(0xFFFFEBEE), Color(0xFFC62828), "Bỏ lỡ")
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.padding(top = 4.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun ValueInputDialog(
    occurrence: HabitOccurrence,
    onDismiss: () -> Unit,
    onSubmit: (Double) -> Unit
) {
    var textValue by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nhập giá trị (${occurrence.unit})") },
        text = {
            OutlinedTextField(
                value = textValue,
                onValueChange = { textValue = it },
                label = { Text("Mục tiêu: ${occurrence.targetValue} ${occurrence.unit}") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    val doubleVal = textValue.toDoubleOrNull() ?: 1.0
                    onSubmit(doubleVal)
                }
            ) {
                Text("Lưu")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}