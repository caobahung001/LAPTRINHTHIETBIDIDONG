package com.habitflow.feature.today

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    viewModel: TodayViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hôm nay (${state.selectedDate})") }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            if (state.isLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            } else if (state.occurrences.isEmpty()) {
                Text(
                    text = "Không có thói quen nào cho ngày hôm nay 🎉",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    item {
                        TodayHeaderProgressCard(
                            completionPercentage = state.completionPercentage,
                            summaryText = state.completionSummaryText,
                            currentStreak = state.currentStreak,
                            bestStreak = state.bestStreak
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    items(state.occurrences, key = { it.habitId }) { occurrence ->
                        HabitOccurrenceItem(
                            occurrence = occurrence,
                            onAction = viewModel::onAction
                        )
                    }
                }
            }

            // Milestone Banner Alert
            AnimatedVisibility(
                visible = state.milestoneMessage != null,
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                state.milestoneMessage?.let { msg ->
                    Snackbar(
                        action = {
                            TextButton(onClick = { viewModel.onAction(TodayAction.DismissMilestoneAlert) }) {
                                Text("OK")
                            }
                        },
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(msg)
                    }
                }
            }

            // Value Input Dialog for Numeric Habits
            if (state.isValueInputDialogVisible && state.targetHabitForValue != null) {
                ValueInputDialog(
                    occurrence = state.targetHabitForValue!!,
                    onDismiss = { viewModel.onAction(TodayAction.DismissValueInputDialog) },
                    onSubmit = { value ->
                        viewModel.onAction(TodayAction.SubmitValueInput(state.targetHabitForValue!!.habitId, value))
                    }
                )
            }
        }
    }
}