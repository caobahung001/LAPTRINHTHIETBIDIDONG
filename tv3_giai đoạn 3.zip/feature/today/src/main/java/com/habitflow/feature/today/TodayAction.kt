package com.habitflow.feature/today

import com.habitflow.core.domain.model.HabitOccurrence
import java.time.LocalDate

sealed interface TodayAction {
    data class CompleteHabit(val habitId: Long) : TodayAction
    data class SkipHabit(val habitId: Long) : TodayAction
    data class UndoHabit(val habitId: Long) : TodayAction
    data class OpenValueInputDialog(val occurrence: HabitOccurrence) : TodayAction
    data class SubmitValueInput(val habitId: Long, val value: Double) : TodayAction
    object DismissValueInputDialog : TodayAction
    data class SelectDate(val date: LocalDate) : TodayAction
    object DismissMilestoneAlert : TodayAction
    object RefreshTodayData : TodayAction
}