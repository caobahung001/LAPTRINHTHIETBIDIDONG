package com.habitflow.feature.today

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.habitflow.core.domain.calculator.CompletionRateCalculator
import com.habitflow.core.domain.calculator.StreakCalculator
import com.habitflow.core.domain.usecase.occurrence.AddValueHabitUseCase
import com.habitflow.core.domain.usecase.occurrence.AutoMarkMissedUseCase
import com.habitflow.core.domain.usecase.occurrence.CompleteHabitUseCase
import com.habitflow.core.domain.usecase.occurrence.ObserveTodayUseCase
import com.habitflow.core.domain.usecase.occurrence.SkipHabitUseCase
import com.habitflow.core.domain.usecase.occurrence.UndoHabitUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class TodayViewModel @Inject constructor(
    private val observeTodayUseCase: ObserveTodayUseCase,
    private val completeHabitUseCase: CompleteHabitUseCase,
    private val skipHabitUseCase: SkipHabitUseCase,
    private val undoHabitUseCase: UndoHabitUseCase,
    private val addValueHabitUseCase: AddValueHabitUseCase,
    private val autoMarkMissedUseCase: AutoMarkMissedUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(TodayUiState())
    val uiState: StateFlow<TodayUiState> = _uiState.asStateFlow()

    init {
        checkAndMarkMissed()
        loadOccurrencesForDate(LocalDate.now())
    }

    fun onAction(action: TodayAction) {
        when (action) {
            is TodayAction.CompleteHabit -> completeHabit(action.habitId)
            is TodayAction.SkipHabit -> skipHabit(action.habitId)
            is TodayAction.UndoHabit -> undoHabit(action.habitId)
            is TodayAction.OpenValueInputDialog -> {
                _uiState.update {
                    it.copy(
                        isValueInputDialogVisible = true,
                        targetHabitForValue = action.occurrence
                    )
                }
            }
            is TodayAction.SubmitValueInput -> submitValueInput(action.habitId, action.value)
            TodayAction.DismissValueInputDialog -> {
                _uiState.update {
                    it.copy(isValueInputDialogVisible = false, targetHabitForValue = null)
                }
            }
            is TodayAction.SelectDate -> loadOccurrencesForDate(action.date)
            TodayAction.DismissMilestoneAlert -> {
                _uiState.update { it.copy(milestoneMessage = null) }
            }
            TodayAction.RefreshTodayData -> loadOccurrencesForDate(_uiState.value.selectedDate)
        }
    }

    private fun checkAndMarkMissed() {
        viewModelScope.launch {
            try {
                autoMarkMissedUseCase(LocalDate.now())
            } catch (e: Exception) {
                // Log error
            }
        }
    }

    private fun loadOccurrencesForDate(date: LocalDate) {
        _uiState.update { it.copy(isLoading = true, selectedDate = date) }
        viewModelScope.launch {
            observeTodayUseCase(date).collectLatest { list ->
                val rate = CompletionRateCalculator.calculateDailyCompletionRate(list)
                val summary = CompletionRateCalculator.getCompletionSummaryText(list)
                val streakInfo = StreakCalculator.calculateStreak(list, date)

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        occurrences = list,
                        completionPercentage = rate.toFloat(),
                        completionSummaryText = summary,
                        currentStreak = streakInfo.currentStreak,
                        bestStreak = streakInfo.bestStreak,
                        milestoneMessage = streakInfo.milestoneMessage
                    )
                }
            }
        }
    }

    private fun completeHabit(habitId: Long) {
        viewModelScope.launch {
            completeHabitUseCase(habitId, _uiState.value.selectedDate)
        }
    }

    private fun skipHabit(habitId: Long) {
        viewModelScope.launch {
            skipHabitUseCase(habitId, _uiState.value.selectedDate)
        }
    }

    private fun undoHabit(habitId: Long) {
        viewModelScope.launch {
            undoHabitUseCase(habitId, _uiState.value.selectedDate)
        }
    }

    private fun submitValueInput(habitId: Long, value: Double) {
        viewModelScope.launch {
            addValueHabitUseCase(habitId, value, _uiState.value.selectedDate)
            _uiState.update {
                it.copy(isValueInputDialogVisible = false, targetHabitForValue = null)
            }
        }
    }
}