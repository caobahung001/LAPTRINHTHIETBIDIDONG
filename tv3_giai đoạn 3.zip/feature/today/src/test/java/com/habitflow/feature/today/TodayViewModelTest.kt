package com.habitflow.feature.today

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.usecase.occurrence.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.*
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class TodayViewModelTest {

    private val testDispatcher = StandardTestDispatcher()
    private val observeTodayUseCase = mock(ObserveTodayUseCase::class.java)
    private val completeHabitUseCase = mock(CompleteHabitUseCase::class.java)
    private val skipHabitUseCase = mock(SkipHabitUseCase::class.java)
    private val undoHabitUseCase = mock(UndoHabitUseCase::class.java)
    private val addValueHabitUseCase = mock(AddValueHabitUseCase::class.java)
    private val autoMarkMissedUseCase = mock(AutoMarkMissedUseCase::class.java)

    private lateinit var viewModel: TodayViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        `when`(observeTodayUseCase(any())).thenReturn(flowOf(emptyList()))
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `loadOccurrences calculates correct status and completion rate`() = runTest {
        val today = LocalDate.now()
        val mockData = listOf(
            HabitOccurrence(habitId = 1, date = today, status = OccurrenceStatus.COMPLETED),
            HabitOccurrence(habitId = 2, date = today, status = OccurrenceStatus.PENDING)
        )
        `when`(observeTodayUseCase(today)).thenReturn(flowOf(mockData))

        viewModel = TodayViewModel(
            observeTodayUseCase,
            completeHabitUseCase,
            skipHabitUseCase,
            undoHabitUseCase,
            addValueHabitUseCase,
            autoMarkMissedUseCase
        )

        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(50f, viewModel.uiState.value.completionPercentage, 0.1f)
        assertEquals(2, viewModel.uiState.value.occurrences.size)
    }
}