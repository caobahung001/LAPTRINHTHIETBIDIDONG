package com.habitflow.feature/today

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.habitflow.core.domain.model.OccurrenceStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    viewModel: TodayViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var activeNoteDialogHabit by remember { mutableStateOf<TodayItemUiState?>(null) }

    LaunchedEffect(uiState.userMessage) {
        uiState.userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.onAction(TodayAction.ClearMessage)
        }
    }

    LaunchedEffect(uiState.undoState) {
        uiState.undoState?.let { undo ->
            val result = snackbarHostState.showSnackbar(
                message = "Đã cập nhật '${undo.habitTitle}'",
                actionLabel = "HOÀN TÁC",
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) {
                viewModel.onAction(TodayAction.UndoLastAction)
            } else {
                viewModel.onAction(TodayAction.DismissUndoSnackbar)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Hôm nay", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { viewModel.onAction(TodayAction.QuickCompleteAll) }) {
                        Icon(imageVector = Icons.Default.DoneAll, contentDescription = "Hoàn thành tất cả")
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Milestone alert banner if present
            uiState.milestoneInfo?.let { milestone ->
                MilestoneBanner(message = milestone.message, modifier = Modifier.padding(vertical = 8.dp))
            }

            // Quick stats
            StatsOverviewCard(
                currentStreak = uiState.currentStreak,
                weeklyRate = uiState.weeklyCompletionRate,
                monthlyRate = uiState.monthlyCompletionRate,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Filter chips & Quick actions
            FilterSortHeader(
                selectedFilter = uiState.selectedFilter,
                selectedSort = uiState.selectedSort,
                onFilterSelected = { viewModel.onAction(TodayAction.SetFilter(it)) },
                onSortSelected = { viewModel.onAction(TodayAction.SetSort(it)) },
                onQuickCompleteAll = { viewModel.onAction(TodayAction.QuickCompleteAll) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (uiState.filteredHabits.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Không có thói quen nào!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(uiState.filteredHabits, key = { it.habitId }) { item ->
                        HabitCard(
                            item = item,
                            onComplete = { viewModel.onAction(TodayAction.CompleteHabit(item.habitId)) },
                            onSkip = { viewModel.onAction(TodayAction.SkipHabit(item.habitId)) },
                            onAddNote = { activeNoteDialogHabit = item }
                        )
                    }
                }
            }
        }

        activeNoteDialogHabit?.let { item ->
            NoteInputDialog(
                title = item.title,
                onDismiss = { activeNoteDialogHabit = null },
                onConfirm = { note ->
                    viewModel.onAction(TodayAction.CompleteHabit(item.habitId, note = note))
                    activeNoteDialogHabit = null
                }
            )
        }
    }
}

@Composable
private fun HabitCard(
    item: TodayItemUiState,
    onComplete: () -> Unit,
    onSkip: () -> Unit,
    onAddNote: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (item.status) {
                OccurrenceStatus.COMPLETED -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                OccurrenceStatus.SKIPPED -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                else -> MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                item.note?.let { note ->
                    Text(text = "📝 $note", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onAddNote) {
                    Icon(imageVector = Icons.Default.EditNote, contentDescription = "Thêm ghi chú")
                }
                IconButton(onClick = onSkip) {
                    Icon(imageVector = Icons.Default.Block, contentDescription = "Bỏ qua", tint = MaterialTheme.colorScheme.error)
                }
                IconButton(onClick = onComplete) {
                    Icon(
                        imageVector = if (item.status == OccurrenceStatus.COMPLETED) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Hoàn thành",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
