package com.habitflow.feature/today

import com.habitflow.core.domain.model.HabitOccurrence
import java.time.LocalDate

sealed interface TodayAction {
    data class SelectDate(val date: LocalDate) : TodayAction
    data class CompleteHabit(val habitId: Long, val note: String? = null) : TodayAction
    data class SkipHabit(val habitId: Long, val useStreakFreeze: Boolean = false, val note: String? = null) : TodayAction
    data class AddValue(val habitId: Long, val value: Double, val target: Double) : TodayAction
    object QuickCompleteAll : TodayAction
    data class SetFilter(val filter: HabitFilter) : TodayAction
    data class SetSort(val sort: HabitSort) : TodayAction
    object UndoLastAction : TodayAction
    object DismissUndoSnackbar : TodayAction
    object ClearMessage : TodayAction
}
