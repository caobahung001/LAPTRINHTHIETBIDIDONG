package com.habitflow.feature/today

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.model.StreakMilestoneInfo
import java.time.LocalDate

enum class HabitFilter {
    ALL,
    PENDING,
    COMPLETED,
    SKIPPED
}

enum class HabitSort {
    TIME,
    PRIORITY,
    NAME
}

data class TodayItemUiState(
    val habitId: Long,
    val title: String,
    val iconName: String,
    val colorHex: String,
    val priority: Int = 1,
    val isNumeric: Boolean = false,
    val unit: String = "",
    val occurrence: HabitOccurrence? = null
) {
    val status: OccurrenceStatus get() = occurrence?.status ?: OccurrenceStatus.PENDING
    val completedValue: Double get() = occurrence?.completedValue ?: 0.0
    val targetValue: Double get() = occurrence?.targetValue ?: 1.0
    val note: String? get() = occurrence?.note
}

data class UndoState(
    val habitId: Long,
    val habitTitle: String,
    val previousOccurrence: HabitOccurrence?
)

data class TodayUiState(
    val selectedDate: LocalDate = LocalDate.now(),
    val habits: List<TodayItemUiState> = emptyList(),
    val filteredHabits: List<TodayItemUiState> = emptyList(),
    val isLoading: Boolean = false,
    val selectedFilter: HabitFilter = HabitFilter.ALL,
    val selectedSort: HabitSort = HabitSort.TIME,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val weeklyCompletionRate: Float = 0f,
    val monthlyCompletionRate: Float = 0f,
    val milestoneInfo: StreakMilestoneInfo? = null,
    val undoState: UndoState? = null,
    val userMessage: String? = null
)
