package com.habitflow.feature/today

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.habitflow.core.domain.calculator.CompletionRateCalculator
import com.habitflow.core.domain.calculator.StreakCalculator
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.repository.OccurrenceRepository
import com.habitflow.core.domain.usecase.occurrence.AddValueHabitUseCase
import com.habitflow.core.domain.usecase.occurrence.CompleteHabitUseCase
import com.habitflow.core.domain.usecase.occurrence.ObserveTodayUseCase
import com.habitflow.core.domain.usecase.occurrence.SkipHabitUseCase
import com.habitflow.core.domain.usecase.occurrence.UndoHabitUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class TodayViewModel @Inject constructor(
    private val observeTodayUseCase: ObserveTodayUseCase,
    private val completeHabitUseCase: CompleteHabitUseCase,
    private val skipHabitUseCase: SkipHabitUseCase,
    private val undoHabitUseCase: UndoHabitUseCase,
    private val addValueHabitUseCase: AddValueHabitUseCase,
    private val occurrenceRepository: OccurrenceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TodayUiState())
    val uiState: StateFlow<TodayUiState> = _uiState.asStateFlow()

    init {
        loadDataForDate(_uiState.value.selectedDate)
    }

    fun onAction(action: TodayAction) {
        when (action) {
            is TodayAction.SelectDate -> {
                _uiState.update { it.copy(selectedDate = action.date) }
                loadDataForDate(action.date)
            }
            is TodayAction.CompleteHabit -> completeHabit(action.habitId, action.note)
            is TodayAction.SkipHabit -> skipHabit(action.habitId, action.useStreakFreeze, action.note)
            is TodayAction.AddValue -> addValue(action.habitId, action.value, action.target)
            TodayAction.QuickCompleteAll -> quickCompleteAll()
            is TodayAction.SetFilter -> setFilter(action.filter)
            is TodayAction.SetSort -> setSort(action.sort)
            TodayAction.UndoLastAction -> undoLastAction()
            TodayAction.DismissUndoSnackbar -> _uiState.update { it.copy(undoState = null) }
            TodayAction.ClearMessage -> _uiState.update { it.copy(userMessage = null) }
        }
    }

    private fun loadDataForDate(date: LocalDate) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            observeTodayUseCase(date).collectLatest { occurrences ->
                val allOccurrencesInRange = occurrenceRepository.getOccurrencesInRange(
                    date.minusDays(365), date
                )

                val streakResult = StreakCalculator.calculateStreak(allOccurrencesInRange, date)
                val rates = CompletionRateCalculator.calculateRates(allOccurrencesInRange, date)

                _uiState.update { state ->
                    val updatedItems = state.habits.map { item ->
                        val occ = occurrences.find { it.habitId == item.habitId }
                        item.copy(occurrence = occ)
                    }
                    val filtered = applyFilterAndSort(updatedItems, state.selectedFilter, state.selectedSort)

                    state.copy(
                        habits = updatedItems,
                        filteredHabits = filtered,
                        isLoading = false,
                        currentStreak = streakResult.currentStreak,
                        longestStreak = streakResult.longestStreak,
                        milestoneInfo = streakResult.milestoneInfo,
                        weeklyCompletionRate = rates.weeklyRate,
                        monthlyCompletionRate = rates.monthlyRate
                    )
                }
            }
        }
    }

    private fun completeHabit(habitId: Long, note: String?) {
        viewModelScope.launch {
            val date = _uiState.value.selectedDate
            val habit = _uiState.value.habits.find { it.habitId == habitId }
            val prevOcc = habit?.occurrence

            completeHabitUseCase(habitId = habitId, date = date, note = note)

            _uiState.update {
                it.copy(
                    undoState = UndoState(
                        habitId = habitId,
                        habitTitle = habit?.title ?: "Thói quen",
                        previousOccurrence = prevOcc
                    ),
                    userMessage = "Đã hoàn thành '${habit?.title}'!"
                )
            }
        }
    }

    private fun skipHabit(habitId: Long, useFreeze: Boolean, note: String?) {
        viewModelScope.launch {
            val date = _uiState.value.selectedDate
            val habit = _uiState.value.habits.find { it.habitId == habitId }
            val prevOcc = habit?.occurrence

            skipHabitUseCase(habitId = habitId, date = date, useStreakFreeze = useFreeze, note = note)

            _uiState.update {
                it.copy(
                    undoState = UndoState(
                        habitId = habitId,
                        habitTitle = habit?.title ?: "Thói quen",
                        previousOccurrence = prevOcc
                    ),
                    userMessage = "Đã bỏ qua '${habit?.title}'"
                )
            }
        }
    }

    private fun addValue(habitId: Long, added: Double, target: Double) {
        viewModelScope.launch {
            addValueHabitUseCase(habitId, added, target, _uiState.value.selectedDate)
        }
    }

    private fun quickCompleteAll() {
        viewModelScope.launch {
            val pendingHabits = _uiState.value.filteredHabits.filter {
                it.status == OccurrenceStatus.PENDING && !it.isNumeric
            }
            val date = _uiState.value.selectedDate

            pendingHabits.forEach { habit ->
                completeHabitUseCase(habitId = habit.habitId, date = date)
            }

            _uiState.update {
                it.copy(userMessage = "Đã hoàn thành ${pendingHabits.size} thói quen!")
            }
        }
    }

    private fun setFilter(filter: HabitFilter) {
        _uiState.update {
            it.copy(
                selectedFilter = filter,
                filteredHabits = applyFilterAndSort(it.habits, filter, it.selectedSort)
            )
        }
    }

    private fun setSort(sort: HabitSort) {
        _uiState.update {
            it.copy(
                selectedSort = sort,
                filteredHabits = applyFilterAndSort(it.habits, it.selectedFilter, sort)
            )
        }
    }

    private fun undoLastAction() {
        val undo = _uiState.value.undoState ?: return
        viewModelScope.launch {
            val date = _uiState.value.selectedDate
            if (undo.previousOccurrence == null) {
                undoHabitUseCase(undo.habitId, date)
            } else {
                occurrenceRepository.saveOccurrence(undo.previousOccurrence)
            }
            _uiState.update {
                it.copy(undoState = null, userMessage = "Đã hoàn tác thao tác cho '${undo.habitTitle}'")
            }
        }
    }

    private fun applyFilterAndSort(
        items: List<TodayItemUiState>,
        filter: HabitFilter,
        sort: HabitSort
    ): List<TodayItemUiState> {
        val filtered = when (filter) {
            HabitFilter.ALL -> items
            HabitFilter.PENDING -> items.filter { it.status == OccurrenceStatus.PENDING }
            HabitFilter.COMPLETED -> items.filter { it.status == OccurrenceStatus.COMPLETED }
            HabitFilter.SKIPPED -> items.filter { it.status == OccurrenceStatus.SKIPPED }
        }

        return when (sort) {
            HabitSort.TIME -> filtered // Assumes natural daily schedule order
            HabitSort.PRIORITY -> filtered.sortedByDescending { it.priority }
            HabitSort.NAME -> filtered.sortedBy { it.title }
        }
    }
}
