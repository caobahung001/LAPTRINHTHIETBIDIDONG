package com.habitflow.core.domain.repository

import com.habitflow.core.domain.model.HabitOccurrence
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

interface OccurrenceRepository {
    fun getOccurrencesByDate(date: LocalDate): Flow<List<HabitOccurrence>>
    fun getOccurrencesForHabit(habitId: Long): Flow<List<HabitOccurrence>>
    suspend fun getOccurrence(habitId: Long, date: LocalDate): HabitOccurrence?
    suspend fun saveOccurrence(occurrence: HabitOccurrence): Long
    suspend fun deleteOccurrence(habitId: Long, date: LocalDate)
    suspend fun autoMarkPastPendingAsMissed(today: LocalDate): Int
    suspend fun getOccurrencesInRange(startDate: LocalDate, endDate: LocalDate): List<HabitOccurrence>
}
