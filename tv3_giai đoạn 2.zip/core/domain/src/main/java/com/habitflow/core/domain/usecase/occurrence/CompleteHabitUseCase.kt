package com.habitflow.core.domain.usecase.occurrence

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.repository.OccurrenceRepository
import java.time.LocalDate
import javax.inject.Inject

class CompleteHabitUseCase @Inject constructor(
    private val repository: OccurrenceRepository
) {
    suspend operator fun invoke(
        habitId: Long,
        date: LocalDate = LocalDate.now(),
        targetValue: Double = 1.0,
        note: String? = null
    ) {
        val existing = repository.getOccurrence(habitId, date)
        val updated = existing?.copy(
            status = OccurrenceStatus.COMPLETED,
            completedValue = targetValue,
            note = note ?: existing.note,
            updatedAt = System.currentTimeMillis()
        ) ?: HabitOccurrence(
            habitId = habitId,
            date = date,
            status = OccurrenceStatus.COMPLETED,
            completedValue = targetValue,
            targetValue = targetValue,
            note = note
        )
        repository.saveOccurrence(updated)
    }
}
