package com.habitflow.core.domain.usecase.occurrence

import com.habitflow.core.domain.repository.OccurrenceRepository
import java.time.LocalDate
import javax.inject.Inject

class UndoHabitUseCase @Inject constructor(
    private val repository: OccurrenceRepository
) {
    suspend operator fun invoke(
        habitId: Long,
        date: LocalDate = LocalDate.now()
    ) {
        repository.deleteOccurrence(habitId, date)
    }
}
