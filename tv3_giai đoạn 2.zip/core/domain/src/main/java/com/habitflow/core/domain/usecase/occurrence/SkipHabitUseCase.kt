package com.habitflow.core.domain.usecase.occurrence

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.repository.OccurrenceRepository
import java.time.LocalDate
import javax.inject.Inject

class SkipHabitUseCase @Inject constructor(
    private val repository: OccurrenceRepository
) {
    suspend operator fun invoke(
        habitId: Long,
        date: LocalDate = LocalDate.now(),
        useStreakFreeze: Boolean = false,
        note: String? = null
    ) {
        val existing = repository.getOccurrence(habitId, date)
        val updated = existing?.copy(
            status = OccurrenceStatus.SKIPPED,
            isFreezeUsed = useStreakFreeze,
            note = note ?: existing.note,
            updatedAt = System.currentTimeMillis()
        ) ?: HabitOccurrence(
            habitId = habitId,
            date = date,
            status = OccurrenceStatus.SKIPPED,
            isFreezeUsed = useStreakFreeze,
            note = note
        )
        repository.saveOccurrence(updated)
    }
}
