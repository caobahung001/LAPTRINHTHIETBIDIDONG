package com.habitflow.core.domain.model

data class StreakMilestoneInfo(
    val currentStreak: Int,
    val nextMilestone: Int,
    val daysRemaining: Int,
    val message: String
)
