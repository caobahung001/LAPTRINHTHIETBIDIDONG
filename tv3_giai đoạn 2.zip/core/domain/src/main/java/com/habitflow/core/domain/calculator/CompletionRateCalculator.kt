package com.habitflow.core.domain.calculator

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import java.time.LocalDate

data class CompletionRates(
    val dailyRate: Float,
    val weeklyRate: Float,
    val monthlyRate: Float
)

object CompletionRateCalculator {

    fun calculateRates(
        occurrences: List<HabitOccurrence>,
        today: LocalDate = LocalDate.now()
    ): CompletionRates {
        val daily = calculateForPeriod(occurrences, today, today)
        val weekly = calculateForPeriod(occurrences, today.minusDays(6), today)
        val monthly = calculateForPeriod(occurrences, today.minusDays(29), today)

        return CompletionRates(
            dailyRate = daily,
            weeklyRate = weekly,
            monthlyRate = monthly
        )
    }

    private fun calculateForPeriod(
        occurrences: List<HabitOccurrence>,
        startDate: LocalDate,
        endDate: LocalDate
    ): Float {
        val periodOccurrences = occurrences.filter { it.date in startDate..endDate }
        if (periodOccurrences.isEmpty()) return 0f

        val completedCount = periodOccurrences.count { it.status == OccurrenceStatus.COMPLETED }
        val totalValidCount = periodOccurrences.count { it.status != OccurrenceStatus.SKIPPED }

        if (totalValidCount == 0) return 1f // If all skipped, rate is 100%
        return (completedCount.toFloat() / totalValidCount.toFloat()).coerceIn(0f, 1f)
    }
}
