package com.habitflow.core.domain.model

import java.time.LocalDate

enum class OccurrenceStatus {
    PENDING,
    COMPLETED,
    SKIPPED,
    MISSED
}

data class HabitOccurrence(
    val id: Long = 0,
    val habitId: Long,
    val date: LocalDate,
    val status: OccurrenceStatus = OccurrenceStatus.PENDING,
    val completedValue: Double = 0.0,
    val targetValue: Double = 1.0,
    val isFreezeUsed: Boolean = false,
    val note: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
) {
    val isCompleted: Boolean get() = status == OccurrenceStatus.COMPLETED
    val progressRatio: Float get() = if (targetValue > 0) (completedValue / targetValue).coerceIn(0.0, 1.0).toFloat() else 0f
}
