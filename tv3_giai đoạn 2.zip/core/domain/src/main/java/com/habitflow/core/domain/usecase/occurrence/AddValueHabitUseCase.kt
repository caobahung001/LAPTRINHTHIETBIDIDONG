package com.habitflow.core.domain.usecase.occurrence

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.repository.OccurrenceRepository
import java.time.LocalDate
import javax.inject.Inject

class AddValueHabitUseCase @Inject constructor(
    private val repository: OccurrenceRepository
) {
    suspend operator fun invoke(
        habitId: Long,
        addedValue: Double,
        targetValue: Double,
        date: LocalDate = LocalDate.now()
    ) {
        val existing = repository.getOccurrence(habitId, date)
        val currentVal = existing?.completedValue ?: 0.0
        val newVal = currentVal + addedValue
        val isCompleted = newVal >= targetValue

        val updated = existing?.copy(
            completedValue = newVal,
            targetValue = targetValue,
            status = if (isCompleted) OccurrenceStatus.COMPLETED else OccurrenceStatus.PENDING,
            updatedAt = System.currentTimeMillis()
        ) ?: HabitOccurrence(
            habitId = habitId,
            date = date,
            completedValue = newVal,
            targetValue = targetValue,
            status = if (isCompleted) OccurrenceStatus.COMPLETED else OccurrenceStatus.PENDING
        )
        repository.saveOccurrence(updated)
    }
}
