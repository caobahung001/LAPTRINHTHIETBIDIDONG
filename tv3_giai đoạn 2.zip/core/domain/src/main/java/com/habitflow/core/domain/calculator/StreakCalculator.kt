package com.habitflow.core.domain.calculator

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus
import com.habitflow.core.domain.model.StreakMilestoneInfo
import java.time.LocalDate

data class StreakResult(
    val currentStreak: Int,
    val longestStreak: Int,
    val milestoneInfo: StreakMilestoneInfo?
)

object StreakCalculator {

    private val MILESTONES = listOf(3, 7, 14, 21, 30, 50, 100, 365)

    fun calculateStreak(
        occurrences: List<HabitOccurrence>,
        today: LocalDate = LocalDate.now()
    ): StreakResult {
        if (occurrences.isEmpty()) {
            return StreakResult(0, 0, getMilestoneInfo(0))
        }

        val sorted = occurrences.sortedByDescending { it.date }
        val occurrenceMap = sorted.associateBy { it.date }

        var currentStreak = 0
        var checkDate = today

        // If today hasn't been completed yet, check if yesterday was completed
        val todayOccurrence = occurrenceMap[today]
        if (todayOccurrence == null || todayOccurrence.status == OccurrenceStatus.PENDING) {
            checkDate = today.minusDays(1)
        }

        // Count current streak back in time
        while (true) {
            val occ = occurrenceMap[checkDate] ?: break
            when {
                occ.status == OccurrenceStatus.COMPLETED -> {
                    currentStreak++
                    checkDate = checkDate.minusDays(1)
                }
                occ.status == OccurrenceStatus.SKIPPED && occ.isFreezeUsed -> {
                    // Grace period / Streak freeze used: preserve streak without incrementing
                    checkDate = checkDate.minusDays(1)
                }
                else -> break
            }
        }

        // Calculate longest streak
        var longestStreak = 0
        var tempStreak = 0
        val datesAscending = occurrences.sortedBy { it.date }

        for (occ in datesAscending) {
            when {
                occ.status == OccurrenceStatus.COMPLETED -> {
                    tempStreak++
                    if (tempStreak > longestStreak) longestStreak = tempStreak
                }
                occ.status == OccurrenceStatus.SKIPPED && occ.isFreezeUsed -> {
                    // Streak freeze keeps existing temp streak alive
                }
                else -> {
                    tempStreak = 0
                }
            }
        }

        return StreakResult(
            currentStreak = currentStreak,
            longestStreak = maxOf(currentStreak, longestStreak),
            milestoneInfo = getMilestoneInfo(currentStreak)
        )
    }

    private fun getMilestoneInfo(currentStreak: Int): StreakMilestoneInfo? {
        val nextMilestone = MILESTONES.firstOrNull { it > currentStreak } ?: return null
        val daysRemaining = nextMilestone - currentStreak
        val message = if (daysRemaining == 1) {
            "Chỉ còn 1 ngày nữa để đạt mốc $nextMilestone ngày liên tiếp! Cố lên! 🎉"
        } else {
            "Còn $daysRemaining ngày nữa để cán mốc $nextMilestone ngày!"
        }
        return StreakMilestoneInfo(
            currentStreak = currentStreak,
            nextMilestone = nextMilestone,
            daysRemaining = daysRemaining,
            message = message
        )
    }
}
