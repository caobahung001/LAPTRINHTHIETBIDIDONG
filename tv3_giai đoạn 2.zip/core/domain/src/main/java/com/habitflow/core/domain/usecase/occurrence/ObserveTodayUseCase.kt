package com.habitflow.core.domain.usecase.occurrence

import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.repository.OccurrenceRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.onStart
import java.time.LocalDate
import javax.inject.Inject

class ObserveTodayUseCase @Inject constructor(
    private val repository: OccurrenceRepository
) {
    operator fun invoke(date: LocalDate = LocalDate.now()): Flow<List<HabitOccurrence>> {
        return repository.getOccurrencesByDate(date)
            .onStart {
                // Auto mark pending occurrences from previous days as MISSED
                repository.autoMarkPastPendingAsMissed(date)
            }
    }
}
