package com.habitflow.core.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.habitflow.core.database.entity.HabitOccurrenceEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface OccurrenceDao {

    @Query("SELECT * FROM habit_occurrences WHERE date = :date")
    fun getOccurrencesByDate(date: LocalDate): Flow<List<HabitOccurrenceEntity>>

    @Query("SELECT * FROM habit_occurrences WHERE habit_id = :habitId AND date = :date LIMIT 1")
    suspend fun getOccurrence(habitId: Long, date: LocalDate): HabitOccurrenceEntity?

    @Query("SELECT * FROM habit_occurrences WHERE habit_id = :habitId ORDER BY date DESC")
    fun getOccurrencesForHabit(habitId: Long): Flow<List<HabitOccurrenceEntity>>

    @Query("SELECT * FROM habit_occurrences WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getOccurrencesInRange(startDate: LocalDate, endDate: LocalDate): List<HabitOccurrenceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(occurrence: HabitOccurrenceEntity): Long

    @Query("DELETE FROM habit_occurrences WHERE habit_id = :habitId AND date = :date")
    suspend fun deleteOccurrence(habitId: Long, date: LocalDate)

    // Automatically mark uncompleted past occurrences as MISSED
    @Query("""
        UPDATE habit_occurrences 
        SET status = 'MISSED' 
        WHERE date < :today AND status = 'PENDING'
    """)
    suspend fun autoMarkPastPendingAsMissed(today: LocalDate): Int
}
