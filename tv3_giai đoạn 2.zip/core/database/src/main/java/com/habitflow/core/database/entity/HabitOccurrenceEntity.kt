package com.habitflow.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDate

@Entity(
    tableName = "habit_occurrences",
    indices = [
        Index(value = ["habit_id", "date"], unique = true),
        Index(value = ["date"])
    ]
)
data class HabitOccurrenceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    @ColumnInfo(name = "habit_id")
    val habitId: Long,
    
    @ColumnInfo(name = "date")
    val date: LocalDate,
    
    @ColumnInfo(name = "status")
    val status: String, // COMPLETED, SKIPPED, MISSED, PENDING
    
    @ColumnInfo(name = "completed_value")
    val completedValue: Double = 0.0,
    
    @ColumnInfo(name = "target_value")
    val targetValue: Double = 1.0,
    
    @ColumnInfo(name = "is_freeze_used")
    val isFreezeUsed: Boolean = false,
    
    @ColumnInfo(name = "note")
    val note: String? = null,
    
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)
