package com.habitflow.core.data.mapper

import com.habitflow.core.database.entity.HabitOccurrenceEntity
import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.model.OccurrenceStatus

fun HabitOccurrenceEntity.toDomain(): HabitOccurrence {
    return HabitOccurrence(
        id = id,
        habitId = habitId,
        date = date,
        status = runCatching { OccurrenceStatus.valueOf(status) }.getOrDefault(OccurrenceStatus.PENDING),
        completedValue = completedValue,
        targetValue = targetValue,
        isFreezeUsed = isFreezeUsed,
        note = note,
        updatedAt = updatedAt
    )
}

fun HabitOccurrence.toEntity(): HabitOccurrenceEntity {
    return HabitOccurrenceEntity(
        id = id,
        habitId = habitId,
        date = date,
        status = status.name,
        completedValue = completedValue,
        targetValue = targetValue,
        isFreezeUsed = isFreezeUsed,
        note = note,
        updatedAt = updatedAt
    )
}
