package com.habitflow.core.data.repository

import com.habitflow.core.data.mapper.toDomain
import com.habitflow.core.data.mapper.toEntity
import com.habitflow.core.database.dao.OccurrenceDao
import com.habitflow.core.domain.model.HabitOccurrence
import com.habitflow.core.domain.repository.OccurrenceRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import javax.inject.Inject

class OfflineOccurrenceRepository @Inject constructor(
    private val occurrenceDao: OccurrenceDao
) : OccurrenceRepository {

    override fun getOccurrencesByDate(date: LocalDate): Flow<List<HabitOccurrence>> {
        return occurrenceDao.getOccurrencesByDate(date).map { list ->
            list.map { it.toDomain() }
        }
    }

    override fun getOccurrencesForHabit(habitId: Long): Flow<List<HabitOccurrence>> {
        return occurrenceDao.getOccurrencesForHabit(habitId).map { list ->
            list.map { it.toDomain() }
        }
    }

    override suspend fun getOccurrence(habitId: Long, date: LocalDate): HabitOccurrence? {
        return occurrenceDao.getOccurrence(habitId, date)?.toDomain()
    }

    override suspend fun saveOccurrence(occurrence: HabitOccurrence): Long {
        return occurrenceDao.insertOrUpdate(occurrence.toEntity())
    }

    override suspend fun deleteOccurrence(habitId: Long, date: LocalDate) {
        occurrenceDao.deleteOccurrence(habitId, date)
    }

    override suspend fun autoMarkPastPendingAsMissed(today: LocalDate): Int {
        return occurrenceDao.autoMarkPastPendingAsMissed(today)
    }

    override suspend fun getOccurrencesInRange(startDate: LocalDate, endDate: LocalDate): List<HabitOccurrence> {
        return occurrenceDao.getOccurrencesInRange(startDate, endDate).map { it.toDomain() }
    }
}
